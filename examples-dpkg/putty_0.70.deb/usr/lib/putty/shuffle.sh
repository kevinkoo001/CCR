#!/bin/bash

set -e

MANIF="/usr/lib/putty/manifest"
while read line
do
    prander $line
done < "$MANIF"

exit 0
